class Ex{
	public static void main(String[] args) {
		Boolean a = false;
		if ( a = false)
			System.out.println("Not");
			if (a = true)
				System.out.println("Done");
		else
			System.out.println("Uninsigned");
		System.out.println("End");
	}
}