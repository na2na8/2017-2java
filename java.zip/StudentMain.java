import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner 생성
		Scanner sc = new Scanner(System.in);
		int num=1;
		while(num != 0) {
			//메뉴를 출력
			System.out.println("1. 학생정보 등록");
			System.out.println("2. 학생정보 수정");
			System.out.println("3. 학생정보 조회");
			System.out.println("4. 학생정보 삭제");
			System.out.println("0. 프로그램 종료");
			//메뉴 번호 입력
			num = sc.nextInt();
			sc.nextLine();
			//기능 실행
			switch(num){
			case 1:
				//학생정보 등록 부분 실행
				StudentService.getInstance().insertStudentVO(sc);
				break;
			case 2:
				//학생정보 수정 부분 실행
				StudentService.getInstance().updateStudentVO(sc);
				break;
			case 3:
				//학생정보 조회 부분 실행
				StudentService.getInstance().searchStudentVO(sc);
				break;
			case 4:
				//학생정보 삭제 부분 실행
				StudentService.getInstance().deleteStudentVO(sc);
				break;
			case 0:
				//프로그램을 종료합니다 메세지만 출력
			}
			
			
		}
	}

}
