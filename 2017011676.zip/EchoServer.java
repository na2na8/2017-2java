import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class EchoServer {
	
	public static void main(String[] args) {
		try{
		    BufferedReader br;
		    PrintWriter pw;
		    Socket soc;
		    ServerSocket server_Soc = new ServerSocket(8888);
            
            soc = server_Soc.accept();
            System.out.println("Client has accepted!!");
            
            br = new BufferedReader(new InputStreamReader(soc.getInputStream())); // ready to read data from client.
            pw = new PrintWriter(soc.getOutputStream());    // ready to send data from client.
            
            String readData = "";
            
            pw.println("HTTP/1.1 200 OK\r\n");
            pw.flush();
            
            while(!(readData = br.readLine()).trim().equals("")){ //wait
                 System.out.println(readData); //read message that client sent.
                 pw.println(readData); // send message to client
                 pw.flush(); // initialize pw 's memory. data will send if this method runs
            }
            
            soc.close();
            server_Soc.close();
            
        }catch(SocketException | NullPointerException se){
            System.out.println("Program finished since client connect had finished...");
            System.exit(0);
        
        }catch(Exception e){
            e.printStackTrace();
        }
	}
}
